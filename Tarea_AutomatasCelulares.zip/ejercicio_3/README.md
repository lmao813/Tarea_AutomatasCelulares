# Ejercicio 3: Diagrama de Voronoi en Bogotá

Modelo simple que usa diagramas de Voronoi para simular la distribución de colegios y droguerías en Bogotá.
