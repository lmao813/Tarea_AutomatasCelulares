# Ejercicio 2: Robot evita obstáculos

Simulación de un robot con dos ruedas que detecta y esquiva obstáculos usando un comportamiento sencillo de Autómata Celular probabilístico.
