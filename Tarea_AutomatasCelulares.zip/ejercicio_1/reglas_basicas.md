# Reglas básicas de comportamiento

## En Casa
- Apagar las luces de habitaciones no usadas.
- Llevar llaves al salir.
- Revisar puertas y ventanas antes de salir.

## En la Universidad
- Hacer fila para ingresar a la biblioteca.
- Validar identidad en la biblioteca.
- Llevar implementos de seguridad al laboratorio.
- Hacer fila para el comedor.

## En el Transporte
- Cumplir normas de tránsito en transporte particular.
- No obstruir entradas ni salidas en transporte público.
- Dar la silla azul a mayores, embarazadas o discapacitados.
