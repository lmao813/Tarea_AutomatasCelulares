# Tarea de Autómatas Celulares y Mini Robots

Este repositorio contiene la solución de los ejercicios propuestos sobre el tema de Autómatas Celulares y Mini Robots.

## Contenido

- **Ejercicio 1:** Reglas básicas de comportamiento.
- **Ejercicio 2:** Simulación de robot que evita obstáculos.
- **Ejercicio 3:** Diagrama de Voronoi de Bogotá (simulado).
- **Ejercicio 4:** Generación de un Autómata Celular 1D.
