# Ejercicio 4: Impresión de Autómata Celular 1D

Código para generar la estructura de un Autómata Celular 1D simple, con miras a su posterior exportación a formato STL para impresión 3D.
